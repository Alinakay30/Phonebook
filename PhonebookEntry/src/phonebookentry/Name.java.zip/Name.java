/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package phonebookentry;

/**
 *
 * @author QueenB
 */
class Name {

    public String name;

    public Name(String name) {
        this.name = name;
    }

    public boolean equals(Name other) {
        return this.name.equals(other.name);
    }

}
